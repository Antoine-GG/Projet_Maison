/*
 * MASTER.cpp
 *
 * 
 * Author :Mohand et Maxim
 * un bouton Poussoir est reli� sur l'entree PC0 du MASTER (pin 23)
 * une LED est reli�e sur la sortie PD0 du SLAVE (pin2)
 * un appui sur le bouton poussoir du MASTER permet d'allumer la LED du SLAVE
 */ 
#define  F_CPU 8000000UL
#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <util/delay.h>

void SPI_MasterInit(void)
{
	/* Set MOSI and SCK output SS,  */
	DDRB |= (1<<PB3)|(1<<PB5);
	DDRB |= (1<<PB2);//SS du SLAVE 1
	DDRB |= (1<<PB1);//SS du SLAVE2
	/* Enable SPI, Master, set clock rate fck/64 */
	SPCR |= (1<<SPE)|(1<<MSTR)|(1<<SPR1);
}
void SPI_MasterTransmit(char cData)
{
	/* Start transmission */
	SPDR = cData;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)));
}

int main(void)
{   uint8_t donnees;
	 //Bouton Poussoir sur PC0, Activer r�sistance de Rappel
	PORTC |=(1<<PC0);
	PORTC |=(1<<PC1);
	
	SPI_MasterInit();//Initialisation SPI Master
    
	PORTB|=(1<<PB2); //SS du SLAVE1 = 1
	PORTB|=(1<<PB1); //SS dud SLAVE2 =1
	
	
    while (1) 
	
    { 
		//lire l'etat du bouton poussoir
		//donnees pour la lumi�re
		if (bit_is_clear(PINC,PC0))
		donnees=0x01;//si bouton appuy� envoy� 01
		else
		donnees=0x00;//si non envoy� 00
		// controle du SLAVE1
		PORTB &= ~(1<<PB2);//Activ� Slave 1 SS=0
		_delay_us(5);
		SPI_MasterTransmit(donnees); //Transmettre la donnee
		_delay_us(5);
		
		PORTB|=(1<<PB2);//D�sactiv� Slave1 SS=1
		
		
		// controle du SLAVE2
		if (bit_is_clear(PINC,PC1))
		donnees=0x01;//si bouton appuy� envoy� 01
		else
		donnees=0x00;//si non envoy� 00
		
		PORTB &= ~(1<<PB1);//Activ� Slave2 SS=0
		_delay_us(5);
		//donnnes pour le verrou
		SPI_MasterTransmit(donnees); //Transmettre la donnee
		_delay_us(5);
		
		PORTB|=(1<<PB1);//D�sactiv� Slave 2   SS=1
    }  
}

